// JavaScript Document
window.onload = function(){
	console.log("Junior developer test.");
	
	// declare your variables here.
	var background;
	var canvas = document.getElementById("stage"); 
	var width = canvas.width, 
		height = canvas.height,
 		ctx = canvas.getContext("2d");
	var colorList = [[0,"orange"], [0.5,"red"],[1,"blue"]]
	
	
	// store a reference to the canvas which we will draw on.
	var stage = new createjs.Stage("stage");
	
	// register the stage to handle mouse events. 
	stage.enableMouseOver(10);
	
	// register the Ticker to listen for the tick event.
	createjs.Ticker.addEventListener("tick", handleTick, false);
	
	// redraw the canvas - like Event.ENTER_FRAME in Adobe Flash.
	function handleTick(event) {
		stage.update();
	}
	
	// create a preloader to load the images.
	var loader = new createjs.LoadQueue(false);
	
	// when all images are loaded call the handleAllImageLoaded function.
	loader.on('complete', handleAllImagesLoaded, this);
	
	// provide a manifest of files and ids to be loaded.
	loader.loadManifest([
		{id: "background", src:"images/background.png"},
		{id: "deezer_offer", src:"images/deezer_offer.png"},
		{id: "mands_voucher", src:"images/mands_voucher.png"},
	]);
	
	function handleAllImagesLoaded() {
		console.log("All the images have loaded.");
		drawTheBannerBackground();
	}
	
	function drawTheBannerBackground() {
		console.log("draw and animate the background.");
		
		// provide the loader result for the item with id == 'background'
		// as a bitmap which will be stored in our background variable.
		background = new createjs.Bitmap( loader.getResult( "background" ) );
		
		// set the background bitmap alpha to zero.
		background.alpha = 0;
		
		// add background to the display list.
		stage.addChild( background );
		
		// animate the background bitmap alpha value to 1 over the duration of 1000 milliseconds.
		createjs.Tween.get( background ).to( {alpha:1}, 1000 );
		
		// after the background is drawn on the canvas draw and animate the content for frame 1.
		setTimeout(frame1, 100);
	}
	
	// create a bitmap of loader image when required for stage update
	function scaleImage (image, scaleX, scaleY){
		
		var bitmap = new createjs.Bitmap(loader.getResult( image ))
		if(scaleX) bitmap.scaleX = scaleX; 
		if(scaleY) bitmap.scaleY = scaleY; 
	
		return bitmap; 
	}

	// create sky logo text
	function showSkyLogo(){

		var colorList = [[0,"orange"],[0.25,"red"],[0.5,"indigo"],[0.95,"blue"]]
		var skyGradientColor = setGradientColor(colorList,60,35,20,0);
		var sky = new createjs.Text("sky","30px SkyText-Bold", skyGradientColor );
		sky.y = 200;
		sky.x = 14;
		sky.color = skyGradientColor;
		
		stage.addChild(sky);
	}

	// create offer square box on frame2
	function createBroadBandOffer(){
		var width = 150,
			height = width; 
		
		var offerContainer = new createjs.Container(); 
		offerContainer.x = 77;
		offerContainer.y = -1.1*width;
		
		var boxColor = setGradientColor(colorList,width,height)

		var offerBox = new createjs.Shape();
		offerBox.graphics.setStrokeStyle(6).beginStroke(boxColor).drawRoundRect(0, 0, width, height, 10);
		offerContainer.addChild(offerBox);

		var specialOfferColor=setGradientColor(colorList,80,35);

		var specialOffer = new createText("FREE","58px SkyText-Bold",specialOfferColor);
		specialOffer.x =width/2; 
		specialOffer.alpha=1; 
		specialOffer.y = 30;


		var contractColor=setGradientColor(colorList,80,25);

		var contractDuration = createText("12 Months","27px SkyText-Bold",contractColor );
		contractDuration.alpha =1;
		contractDuration.x = width/2;
		contractDuration.y = 10; 

		var skyBroadBandColor = setGradientColor(colorList, 70,50);	
		var skyBroadBand = new createText("SKY BROADBAND", "16px SkyText-Bold", skyBroadBandColor); 
		skyBroadBand.x = width/2;
		skyBroadBand.alpha =1;
		skyBroadBand.y = 90;

		var unlimitedColor=setGradientColor(colorList,60,50);

		var unlimitedOffer = new createText("UNLIMITED", "26px SkyText-Bold", unlimitedColor); 
		unlimitedOffer.x = width/2; 
		unlimitedOffer.alpha =1;
		unlimitedOffer.y = 105;

		offerContainer.addChild(contractDuration, specialOffer, skyBroadBand,unlimitedOffer);

		return offerContainer;
	}

	// create centered text on the stage 
	function createText(text, font, color){
		var _text = new createjs.Text(text,font,color);
		_text.textAlign ="center";
		_text.x = width/2;
		_text.alpha = 0; 
		return _text;	
	}

	
	function createContainer(x,y,dimension){
		var container = new createjs.Container();
		container.x = x;
		container.y = y; 
		container.setBounds(0,0,dimension,dimension)
		return container;
	}
	// create ellipse to build offerBox shadow on frame1
	function CreateEllipse(){
		var ellipse = new createjs.Shape();
		ellipse.graphics.beginFill("rgba(149,149,149,0.5").drawEllipse(0, 0, 70, 4);
		ellipse.x = 10;
		ellipse.y = 88;
		return ellipse;
	}

	// create find more button on frame3
	function createFindMore(){
		var buttonContainer = new createjs.Container(); 
		buttonContainer.x = 140; 
		buttonContainer.y = 190;

		buttonContainer.width = 150; 
		buttonContainer.height = 40; 
		buttonContainer.setBounds(0,0,buttonContainer.width,buttonContainer.height); 

		var _colorList = [[0,"violet"], [1,"darkblue"]]
		var buttonColor = setGradientColor(_colorList, buttonContainer.width, 0);
	
		var buttonBackground = new createjs.Shape(); 
		buttonBackground.graphics.beginFill(buttonColor).drawRoundRect(0,0,buttonContainer.width,buttonContainer.height,10);
		
		buttonContainer.addChild(buttonBackground);
		return buttonContainer;
	}

	function setGradientColor(colors, x,y,x0=0, y0=0){
		
		var _color = ctx.createLinearGradient(x0,y0,x,y);
		colors.forEach(function(color){
			_color.addColorStop(color[0], color[1]);
		});

		return _color;

	}

	// animation functions: TweenJS library functions 
	function fadeIn(obj, time){
		return createjs.Tween.get(obj).to({alpha:1}, time)
	}
	function fadeOut(obj, time){
		return createjs.Tween.get(obj).to({alpha:0}, time)
	}

	function slideInBounce(obj, y, time){
		return createjs.Tween.get(obj).to({y:y},time, createjs.Ease.bounceOut)
	}
	
	// START OF FRAMES 
	function frame1() {
		console.log("draw and animate frame one.");	
		// refer to the creative brief, frame 1 for guidance.
		showSkyLogo(); 

		var gradientColor=setGradientColor(colorList,100,0);

		var headText = createText("Choose your reward", "25px SkyTextMedium-Regular",gradientColor); 
		headText.y = 14;

		var joinOnLineText= createText("when you switch to 12 months\n"+
						" free Sky Broadband Unlimited","14px SkyText-Bold","darkblue" );
		joinOnLineText.lineHeight =14;
		joinOnLineText.y = 40;
		stage.addChild(headText, joinOnLineText);

	 
		var deezerContainer = createContainer(57,114);
		
		var deezerImage = new createjs.Bitmap( loader.getResult( "deezer_offer" ))
		deezerImage.scaleX =0.131; 
		deezerImage.scaleY = 0.131;
		deezerContainer.addChild(deezerImage,CreateEllipse());
		stage.addChild(deezerContainer);

		
		var msContainer = createContainer(164,114);
			
		var msImage = new createjs.Bitmap( loader.getResult( "mands_voucher" ))
		msImage.scaleX =0.3; 
		msImage.scaleY = 0.3;
		msContainer.addChild(msImage, CreateEllipse());
		stage.addChild(msContainer);

		
		createjs.Tween.get(stage)
		.call(fadeIn, [headText,2000], this)
		.wait(2000)
		.call(fadeIn, [joinOnLineText, 2000], this)
		.wait(2000)
		.call(function(objs, time){
				objs.forEach((obj)=>fadeOut(obj,time))
			 }, [stage.children.slice(2), 1000])
		.call(frame2)
		//setTimeout(frame2, 3000);
	}
	
	function frame2() {
		console.log("draw and animate frame two.");
		stage.removeChild(...stage.children.slice(2));

		var gradientColor=setGradientColor(colorList,100,0);

		var headText = createText("When you join Sky with","25px SkyTextMedium-Regular",gradientColor);
		headText.y = 14;
		
		var broadBandOffer = createBroadBandOffer();

		var rentMessage = createText("Sky Line Rental at £16.40pm applies", "10px SkyText-Regular", "gray");
		rentMessage.x = 200;
		rentMessage.y = 220;

		stage.addChild(headText, broadBandOffer, rentMessage);
		createjs.Tween.get(stage)
		.call(fadeIn, [headText,1500], this)
		.wait(1200)
		.call(fadeIn, [rentMessage, 1100], this)
		.call(slideInBounce,[broadBandOffer,60,2100],this)
		.wait(2500)
		.call(frame3)

		//setTimeout(frame3, 3000);
	}
	
	function frame3() {
		console.log("draw and animate frame three.");
		stage.removeChild(...stage.children.slice(2));
		stage.removeChild( background );

		var headColor = setGradientColor(colorList, 100,0);
		var headText = createText("1 year free unlimited music with\n Deezer or £100 M&S Voucher","20px SkyTextMedium-Regular", headColor);
		headText.lineHeight =20;
		headText.y = 14;
		
		var joinOnLineText= createText("when you join online with to 12 months\n"+
						" free Sky Broadband Unlimited","15px SkyText-Bold","darkblue" );
		joinOnLineText.y = 60;

		var limitOffer = new createText("Limited time offer","25px SkyText-Regular",headColor);
		limitOffer.y = 115;
		limitOffer.alpha =0;

		var findMoreButton = createFindMore(); 
	
		var findMore = createText("Find out more","16px SkyText-Bold","white");
		findMore.alpha =1;
		findMore.x = findMoreButton.getBounds().width/2;
		findMore.y = findMoreButton.height/2;
		findMore.textBaseline ="middle";
		findMoreButton.addChild(findMore);
		
		var rentMessage = createText("Sky Line Rental at £16.40pm applies", "10px SkyText-Regular", "gray");
		rentMessage.y = 160;

		// blur/sheen effect on button 
		var blurShape = new createjs.Shape().set({x:findMoreButton.x,y:findMoreButton.y});
 		blurShape.graphics.beginFill("rgb(255,255,255)").drawRoundRect(0,0,10,findMoreButton.height,5);
		blurShape.alpha =0;
 		var blurFilter = new createjs.BlurFilter(20, 10, 1);
 		blurShape.filters = [blurFilter];
 		var bounds = blurFilter.getBounds();
		//  stage.addChild(blurShape);

 		blurShape.cache(-50+bounds.x, bounds.y,50+bounds.width, 50+bounds.height);

		stage.addChild(headText, joinOnLineText, findMoreButton, blurShape,limitOffer, rentMessage);
		
		createjs.Tween.get(stage)
		.wait(800)
		.call(fadeIn, [headText,1200], this)
		.wait(1000)
		.call(fadeIn, [joinOnLineText,1200])
		.wait(600)
		.call(fadeIn, [limitOffer, 1200],this)
		.wait(600)
		.call(fadeIn, [rentMessage,1200], this)
		.call(function(){
							createjs.Tween.get(blurShape)
							.to({alpha:1},800)
							.to({x:findMoreButton.x+findMoreButton.width+10},500)
						}, this
			);
		
		// refer to the creative brief, frame 3 for guidance.
	}
	
};